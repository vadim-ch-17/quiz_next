import colors from "./colors";

const theme = {
    colors,

};


export default theme;