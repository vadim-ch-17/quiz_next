module.exports = {
    i18n: {
        locales: ['en', 'ua'],
        defaultLocale: 'en',
    },
    browserLanguageDetection: false,
}